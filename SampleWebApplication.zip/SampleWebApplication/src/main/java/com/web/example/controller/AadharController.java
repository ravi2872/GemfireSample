package com.web.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.web.example.model.Aadhar;
import com.web.example.service.AadharInterface;

@RestController
@RequestMapping("/api")
public class AadharController {

	@Autowired
	AadharInterface aadharInterface;

	@RequestMapping(value = "/getById", method = RequestMethod.GET)
	public Aadhar getAadharDetailsById(@RequestParam(value = "id") String id) {

		Aadhar aadharinfo = aadharInterface.findAadharinfoById(id);

		return aadharinfo;

	}

	@RequestMapping(value = "/getByName", method = RequestMethod.GET)
	public Aadhar getAadharDetailsbyName(@RequestParam(value = "name") String name) {

		Aadhar aadharinfo = aadharInterface.findAadharinfoByName(name);

		return aadharinfo;

	}

}
