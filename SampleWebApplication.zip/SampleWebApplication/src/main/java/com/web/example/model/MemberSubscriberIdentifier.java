package com.web.example.model;

public class MemberSubscriberIdentifier {

}
