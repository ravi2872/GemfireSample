package com.web.example.service;

import org.springframework.stereotype.Service;

import com.web.example.model.AllOperations;

@Service
public class ArthmaticService {
	
	public AllOperations operations(int a, int b) {
		
		
		PerformCalc p = new PerformCalc();
		AllOperations all = new AllOperations();
		int addition =p.performadd(a, b);
		
		
		
		int sub     =a-b;
		int mul     =a*b;
		all.setAddition(addition);
		all.setSubtraction(sub);
		all.setMultiplication(mul);
		
		return all;
		
	}

}
