package com.web.example.util;


public class Constants {

	public static String wish = "Hello ";

}
