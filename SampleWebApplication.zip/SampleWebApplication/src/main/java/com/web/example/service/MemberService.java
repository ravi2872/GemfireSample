package com.web.example.service;

import com.web.example.model.Member;
import org.springframework.stereotype.Service;

@Service
public interface MemberService {

	public String addMemberDetails(Member member);

	public Member findMemberById(String id);

	public void updateMemberById(String id);

	public void deleteMemberById(Member member);

}
