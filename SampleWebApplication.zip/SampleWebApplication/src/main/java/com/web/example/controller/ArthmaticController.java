package com.web.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.web.example.model.AllOperations;
import com.web.example.service.ArthmaticService;

@RestController
@RequestMapping("/operation")
public class ArthmaticController {
	
	@Autowired
	ArthmaticService As;
	
	

	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public AllOperations add(@RequestParam(value = "a") int a, @RequestParam(value = "b") int b) {
		
		AllOperations aaa = As.operations(a,b) ;
		
		aaa.getAddition();
		aaa.getMultiplication();
		aaa.getSubtraction();
		

		return aaa;
	}

}
