package com.web.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.web.example.model.Member;
import com.web.example.repository.MemberRepository;

@Service
public class MemberServiceImpl implements MemberService {

	@Autowired
	MemberRepository memberRepository;

	public String addMemberDetails(Member member) {

		memberRepository.save(member);

		return "saved Successfully";
	}

	@Override
	public Member findMemberById(String id) {

		Member member = memberRepository.findMemberDetailsById(id);

		return member;
	}

	@Override
	public void updateMemberById(String id) {
		

	}

	@Override
	public void deleteMemberById(Member member) {
		
		Member memberDetails = memberRepository.findMemberDetailsById(member.getMemberKey());

		memberRepository.delete(memberDetails);
	}
}
