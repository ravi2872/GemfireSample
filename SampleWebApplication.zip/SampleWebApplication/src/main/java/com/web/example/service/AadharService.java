package com.web.example.service;

import org.springframework.stereotype.Service;

import com.web.example.model.Aadhar;

@Service
public class AadharService implements AadharInterface {

	public Aadhar findAadharinfoById(String aadharnumber) {

		Aadhar aadhar = new Aadhar();

		aadhar.setId(1);
		aadhar.setName("aaa");
		aadhar.setAge(10);
		aadhar.setPhonenumber(1000);

		return aadhar;

	}

	public Aadhar findAadharinfoByName(String name) {

		Aadhar aadhar = new Aadhar();

		aadhar.setId(1);
		aadhar.setName("aaa");
		aadhar.setAge(10);
		aadhar.setPhonenumber(1000);

		return aadhar;
	}

	
}
