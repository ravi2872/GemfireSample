package com.web.example.service;

public class PerformCalc {

	public int performadd(int a, int b) {

		return a + b;
	}

}
