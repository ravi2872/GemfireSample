package com.web.example.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.web.example.util.Constants;

@RestController
@RequestMapping("/wisher")
public class WishController {

	@RequestMapping(value = "/wish", method = RequestMethod.GET)
	public String wish(@RequestParam(value = "name") String name) {

		return Constants.wish + name;

	}

}
