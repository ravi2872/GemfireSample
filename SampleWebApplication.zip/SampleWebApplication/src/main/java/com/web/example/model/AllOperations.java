package com.web.example.model;

public class AllOperations {

	private int addition;
	private int subtraction;
	private int multiplication;

	public int getAddition() {
		return addition;
	}

	public void setAddition(int addition) {
		this.addition = addition;
	}

	public int getSubtraction() {
		return subtraction;
	}

	public void setSubtraction(int subtraction) {
		this.subtraction = subtraction;
	}

	public int getMultiplication() {
		return multiplication;
	}

	public void setMultiplication(int multiplication) {
		this.multiplication = multiplication;
	}

}
