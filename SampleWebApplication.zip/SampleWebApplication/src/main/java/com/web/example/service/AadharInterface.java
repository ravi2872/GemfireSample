package com.web.example.service;

import com.web.example.model.Aadhar;

public interface AadharInterface {

	Aadhar findAadharinfoById(String aadharnumber);

	Aadhar findAadharinfoByName(String name);
	

}
